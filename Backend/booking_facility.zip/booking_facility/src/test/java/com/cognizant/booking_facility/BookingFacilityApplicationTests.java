package com.cognizant.booking_facility;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class BookingFacilityApplicationTests {

    @Test
    void contextLoads() {
    }
    @Test
    void main() {
    	BookingFacilityApplication.main(new String[] {});
    }

}
