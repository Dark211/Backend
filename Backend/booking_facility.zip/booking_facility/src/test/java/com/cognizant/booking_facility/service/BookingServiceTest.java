package com.cognizant.booking_facility.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.cognizant.booking_facility.entity.Booking;
import com.cognizant.booking_facility.entity.Game;
import com.cognizant.booking_facility.repository.BookingRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ContextConfiguration(classes = {BookingService.class})
@ExtendWith(SpringExtension.class)
class BookingServiceTest {
    @MockBean
    private BookingRepository bookingRepository;

    @Autowired
    private BookingService bookingService;

    @Test
    void testDoBookingCricket() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.CRICKET);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        assertSame(booking, bookingService.doBooking(booking2));
        verify(bookingRepository).save((Booking) any());
        verify(bookingRepository).findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any());
        assertEquals(11, booking2.getGroundNumber());
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    void testDoBookingCricket2() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(LocalTime.of(0, 1));
        when(booking1.getDateOfGame()).thenReturn(LocalDate.ofEpochDay(1L));
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.CRICKET);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        assertSame(booking, bookingService.doBooking(booking2));
        verify(bookingRepository).save((Booking) any());
        verify(bookingRepository).findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any());
        verify(booking1).getDateOfGame();
        verify(booking1).getTimeOfGame();
        verify(booking1).setBookingId(anyInt());
        verify(booking1).setDateOfGame((LocalDate) any());
        verify(booking1).setDob((LocalDate) any());
        verify(booking1).setFirst_name((String) any());
        verify(booking1).setGameName((Game) any());
        verify(booking1).setGroundNumber(anyInt());
        verify(booking1).setLast_name((String) any());
        verify(booking1).setPlayerId((String) any());
        verify(booking1).setTimeOfGame((LocalTime) any());
        assertEquals(1, booking2.getGroundNumber());
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testDoBookingCricket3() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException: Cannot invoke "java.time.LocalTime.equals(Object)" because the return value of "com.cognizant.booking_facility.entity.Booking.getTimeOfGame()" is null
        //       at com.cognizant.booking_facility.service.BookingService.doBooking(BookingService.java:29)
        //   See https://diff.blue/R013 to resolve this issue.

        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(null);
        when(booking1.getDateOfGame()).thenReturn(LocalDate.ofEpochDay(1L));
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.CRICKET);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        bookingService.doBooking(booking2);
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    void testDoBookingCricket4() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(LocalTime.of(1, 1));
        when(booking1.getDateOfGame()).thenReturn(LocalDate.ofEpochDay(-1L));
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.CRICKET);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        assertSame(booking, bookingService.doBooking(booking2));
        verify(bookingRepository).save((Booking) any());
        verify(bookingRepository).findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any());
        verify(booking1).getDateOfGame();
        verify(booking1).setBookingId(anyInt());
        verify(booking1).setDateOfGame((LocalDate) any());
        verify(booking1).setDob((LocalDate) any());
        verify(booking1).setFirst_name((String) any());
        verify(booking1).setGameName((Game) any());
        verify(booking1).setGroundNumber(anyInt());
        verify(booking1).setLast_name((String) any());
        verify(booking1).setPlayerId((String) any());
        verify(booking1).setTimeOfGame((LocalTime) any());
        assertEquals(1, booking2.getGroundNumber());
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testDoBookingCricket5() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException: Cannot invoke "java.time.LocalDate.isEqual(java.time.chrono.ChronoLocalDate)" because the return value of "com.cognizant.booking_facility.entity.Booking.getDateOfGame()" is null
        //       at com.cognizant.booking_facility.service.BookingService.doBooking(BookingService.java:28)
        //   See https://diff.blue/R013 to resolve this issue.

        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(LocalTime.of(1, 1));
        when(booking1.getDateOfGame()).thenReturn(null);
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.CRICKET);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        bookingService.doBooking(booking2);
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    void testDoBookingCricket6() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(Optional.empty());
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(LocalTime.of(1, 1));
        when(booking1.getDateOfGame()).thenReturn(LocalDate.ofEpochDay(1L));
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.CRICKET);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        assertSame(booking, bookingService.doBooking(booking2));
        verify(bookingRepository).save((Booking) any());
        verify(bookingRepository).findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any());
        verify(booking1).setBookingId(anyInt());
        verify(booking1).setDateOfGame((LocalDate) any());
        verify(booking1).setDob((LocalDate) any());
        verify(booking1).setFirst_name((String) any());
        verify(booking1).setGameName((Game) any());
        verify(booking1).setGroundNumber(anyInt());
        verify(booking1).setLast_name((String) any());
        verify(booking1).setPlayerId((String) any());
        verify(booking1).setTimeOfGame((LocalTime) any());
        assertEquals(1, booking2.getGroundNumber());
    }
    
    //BADMINTON
    @Test
    void testDoBookingBadminton() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.BADMINTON);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.BADMINTON);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.BADMINTON);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        assertSame(booking, bookingService.doBooking(booking2));
        verify(bookingRepository).save((Booking) any());
        verify(bookingRepository).findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any());
        assertEquals(3, booking2.getGroundNumber());
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    void testDoBookingBadminton2() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.BADMINTON);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(LocalTime.of(0, 1));
        when(booking1.getDateOfGame()).thenReturn(LocalDate.ofEpochDay(1L));
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.BADMINTON);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.BADMINTON);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        assertSame(booking, bookingService.doBooking(booking2));
        verify(bookingRepository).save((Booking) any());
        verify(bookingRepository).findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any());
        verify(booking1).getDateOfGame();
        verify(booking1).getTimeOfGame();
        verify(booking1).setBookingId(anyInt());
        verify(booking1).setDateOfGame((LocalDate) any());
        verify(booking1).setDob((LocalDate) any());
        verify(booking1).setFirst_name((String) any());
        verify(booking1).setGameName((Game) any());
        verify(booking1).setGroundNumber(anyInt());
        verify(booking1).setLast_name((String) any());
        verify(booking1).setPlayerId((String) any());
        verify(booking1).setTimeOfGame((LocalTime) any());
        assertEquals(3, booking2.getGroundNumber());
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testDoBookingBadminton3() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException: Cannot invoke "java.time.LocalTime.equals(Object)" because the return value of "com.cognizant.booking_facility.entity.Booking.getTimeOfGame()" is null
        //       at com.cognizant.booking_facility.service.BookingService.doBooking(BookingService.java:29)
        //   See https://diff.blue/R013 to resolve this issue.

        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.BADMINTON);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(null);
        when(booking1.getDateOfGame()).thenReturn(LocalDate.ofEpochDay(1L));
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.BADMINTON);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.BADMINTON);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        bookingService.doBooking(booking2);
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    void testDoBookingBadminton4() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.BADMINTON);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(LocalTime.of(1, 1));
        when(booking1.getDateOfGame()).thenReturn(LocalDate.ofEpochDay(-1L));
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.BADMINTON);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.BADMINTON);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        assertSame(booking, bookingService.doBooking(booking2));
        verify(bookingRepository).save((Booking) any());
        verify(bookingRepository).findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any());
        verify(booking1).getDateOfGame();
        verify(booking1).setBookingId(anyInt());
        verify(booking1).setDateOfGame((LocalDate) any());
        verify(booking1).setDob((LocalDate) any());
        verify(booking1).setFirst_name((String) any());
        verify(booking1).setGameName((Game) any());
        verify(booking1).setGroundNumber(anyInt());
        verify(booking1).setLast_name((String) any());
        verify(booking1).setPlayerId((String) any());
        verify(booking1).setTimeOfGame((LocalTime) any());
        assertEquals(3, booking2.getGroundNumber());
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testDoBookingBadminton5() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException: Cannot invoke "java.time.LocalDate.isEqual(java.time.chrono.ChronoLocalDate)" because the return value of "com.cognizant.booking_facility.entity.Booking.getDateOfGame()" is null
        //       at com.cognizant.booking_facility.service.BookingService.doBooking(BookingService.java:28)
        //   See https://diff.blue/R013 to resolve this issue.

        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.FOOTBALL);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(LocalTime.of(1, 1));
        when(booking1.getDateOfGame()).thenReturn(null);
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.BADMINTON);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        Optional<Booking> ofResult = Optional.of(booking1);
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(ofResult);

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.BADMINTON);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        bookingService.doBooking(booking2);
    }

    /**
     * Method under test: {@link BookingService#doBooking(Booking)}
     */
    @Test
    void testDoBookingBadminton6() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.BADMINTON);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        when(bookingRepository.save((Booking) any())).thenReturn(booking);
        when(bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any())).thenReturn(Optional.empty());
        Booking booking1 = mock(Booking.class);
        when(booking1.getTimeOfGame()).thenReturn(LocalTime.of(1, 1));
        when(booking1.getDateOfGame()).thenReturn(LocalDate.ofEpochDay(1L));
        doNothing().when(booking1).setBookingId(anyInt());
        doNothing().when(booking1).setDateOfGame((LocalDate) any());
        doNothing().when(booking1).setDob((LocalDate) any());
        doNothing().when(booking1).setFirst_name((String) any());
        doNothing().when(booking1).setGameName((Game) any());
        doNothing().when(booking1).setGroundNumber(anyInt());
        doNothing().when(booking1).setLast_name((String) any());
        doNothing().when(booking1).setPlayerId((String) any());
        doNothing().when(booking1).setTimeOfGame((LocalTime) any());
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.BADMINTON);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking2 = new Booking();
        booking2.setBookingId(123);
        booking2.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking2.setDob(LocalDate.ofEpochDay(1L));
        booking2.setFirst_name("Jane");
        booking2.setGameName(Game.BADMINTON);
        booking2.setGroundNumber(10);
        booking2.setLast_name("Doe");
        booking2.setPlayerId("42");
        booking2.setTimeOfGame(LocalTime.of(1, 1));
        assertSame(booking, bookingService.doBooking(booking2));
        verify(bookingRepository).save((Booking) any());
        verify(bookingRepository).findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc((Game) any(),
                (LocalDate) any(), (LocalTime) any());
        verify(booking1).setBookingId(anyInt());
        verify(booking1).setDateOfGame((LocalDate) any());
        verify(booking1).setDob((LocalDate) any());
        verify(booking1).setFirst_name((String) any());
        verify(booking1).setGameName((Game) any());
        verify(booking1).setGroundNumber(anyInt());
        verify(booking1).setLast_name((String) any());
        verify(booking1).setPlayerId((String) any());
        verify(booking1).setTimeOfGame((LocalTime) any());
        assertEquals(3, booking2.getGroundNumber());
    }
}

