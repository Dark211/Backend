package com.cognizant.booking_facility.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalTime;

import org.junit.jupiter.api.Test;

class BookingTest {
    /**
     * Method under test: {@link Booking#canEqual(Object)}
     */
    @Test
    void testCanEqual() {
        assertFalse((new Booking()).canEqual("Other"));
    }

    /**
     * Method under test: {@link Booking#canEqual(Object)}
     */
    @Test
    void testCanEqual2() {
        Booking booking = new Booking();

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(3L));
        booking1.setDob(LocalDate.ofEpochDay(3L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(3, 1));
        assertTrue(booking.canEqual(booking1));
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>default or parameterless constructor of {@link Booking}
     *   <li>{@link Booking#setBookingId(int)}
     *   <li>{@link Booking#setDateOfGame(LocalDate)}
     *   <li>{@link Booking#setDob(LocalDate)}
     *   <li>{@link Booking#setFirst_name(String)}
     *   <li>{@link Booking#setGameName(Game)}
     *   <li>{@link Booking#setGroundNumber(int)}
     *   <li>{@link Booking#setLast_name(String)}
     *   <li>{@link Booking#setPlayerId(String)}
     *   <li>{@link Booking#setTimeOfGame(LocalTime)}
     *   <li>{@link Booking#toString()}
     *   <li>{@link Booking#getBookingId()}
     *   <li>{@link Booking#getDateOfGame()}
     *   <li>{@link Booking#getDob()}
     *   <li>{@link Booking#getFirst_name()}
     *   <li>{@link Booking#getGameName()}
     *   <li>{@link Booking#getGroundNumber()}
     *   <li>{@link Booking#getLast_name()}
     *   <li>{@link Booking#getPlayerId()}
     *   <li>{@link Booking#getTimeOfGame()}
     * </ul>
     */
    @Test
    void testConstructor() {
        Booking actualBooking = new Booking();
        actualBooking.setBookingId(123);
        LocalDate ofEpochDayResult = LocalDate.ofEpochDay(1L);
        actualBooking.setDateOfGame(ofEpochDayResult);
        LocalDate ofEpochDayResult1 = LocalDate.ofEpochDay(1L);
        actualBooking.setDob(ofEpochDayResult1);
        actualBooking.setFirst_name("Jane");
        actualBooking.setGameName(Game.CRICKET);
        actualBooking.setGroundNumber(10);
        actualBooking.setLast_name("Doe");
        actualBooking.setPlayerId("42");
        LocalTime ofResult = LocalTime.of(1, 1);
        actualBooking.setTimeOfGame(ofResult);
        String actualToStringResult = actualBooking.toString();
        assertEquals(123, actualBooking.getBookingId());
        assertSame(ofEpochDayResult, actualBooking.getDateOfGame());
        assertSame(ofEpochDayResult1, actualBooking.getDob());
        assertEquals("Jane", actualBooking.getFirst_name());
        assertEquals(Game.CRICKET, actualBooking.getGameName());
        assertEquals(10, actualBooking.getGroundNumber());
        assertEquals("Doe", actualBooking.getLast_name());
        assertEquals("42", actualBooking.getPlayerId());
        assertSame(ofResult, actualBooking.getTimeOfGame());
        assertEquals(
                "Booking(bookingId=123, playerId=42, first_name=Jane, last_name=Doe, dob=1970-01-02, dateOfGame=1970-01-02,"
                        + " timeOfGame=01:01, groundNumber=10, gameName=CRICKET)",
                actualToStringResult);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, null);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals2() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, "Different type to Booking");
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Booking#equals(Object)}
     *   <li>{@link Booking#hashCode()}
     * </ul>
     */
    @Test
    void testEquals3() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        assertEquals(booking, booking);
        int expectedHashCodeResult = booking.hashCode();
        assertEquals(expectedHashCodeResult, booking.hashCode());
    }

    /**
     * Methods under test:
     *
     * <ul>
     *   <li>{@link Booking#equals(Object)}
     *   <li>{@link Booking#hashCode()}
     * </ul>
     */
    @Test
    void testEquals4() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertEquals(booking, booking1);
        int expectedHashCodeResult = booking.hashCode();
        assertEquals(expectedHashCodeResult, booking1.hashCode());
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals5() {
        Booking booking = new Booking();
        booking.setBookingId(1);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals6() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(3L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals7() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(null);
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals8() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(3L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals9() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(null);
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals10() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("42");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals11() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name(null);
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals12() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(null);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals13() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.FOOTBALL);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals14() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(1);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals15() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("42");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals16() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name(null);
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals17() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("Jane");
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals18() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId(null);
        booking.setTimeOfGame(LocalTime.of(1, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals19() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(3, 1));

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }

    /**
     * Method under test: {@link Booking#equals(Object)}
     */
    @Test
    void testEquals20() {
        Booking booking = new Booking();
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(null);

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking1.setDob(LocalDate.ofEpochDay(1L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(1, 1));
        assertNotEquals(booking, booking1);
    }
}

