package com.cognizant.booking_facility.controller;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.cognizant.booking_facility.entity.Booking;
import com.cognizant.booking_facility.entity.Game;
import com.cognizant.booking_facility.feign.RegistrationFeign;
import com.cognizant.booking_facility.service.BookingService;
import com.cognizant.booking_facility.service.SlotService;
import com.cognizant.booking_facility.vo.PlayerResponse;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {BookingController.class})
@ExtendWith(SpringExtension.class)
class BookingControllerTest {
    @Autowired
    private BookingController bookingController;

    @MockBean
    private BookingService bookingService;

    @MockBean
    private RegistrationFeign registrationFeign;

    @MockBean
    private SlotService slotService;

    /**
     * Method under test: {@link BookingController#getAvailableSlots(Booking, String)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testGetAvailableSlots() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException: Cannot invoke "com.cognizant.booking_facility.feign.RegistrationFeign.getTokenValidation(String)" because "this.feign" is null
        //       at com.cognizant.booking_facility.controller.BookingController.getAvailableSlots(BookingController.java:45)
        //   See https://diff.blue/R013 to resolve this issue.

        BookingController bookingController = new BookingController();

        Booking booking1 = new Booking();
        booking1.setBookingId(123);
        booking1.setDateOfGame(LocalDate.ofEpochDay(3L));
        booking1.setDob(LocalDate.ofEpochDay(3L));
        booking1.setFirst_name("Jane");
        booking1.setGameName(Game.CRICKET);
        booking1.setGroundNumber(10);
        booking1.setLast_name("Doe");
        booking1.setPlayerId("42");
        booking1.setTimeOfGame(LocalTime.of(3, 1));
        bookingController.bookSlots(booking1, "ABC123");
    }

    /**
     * Method under test: {@link BookingController#getAvailableSlots(Booking, String)}
     */
    @Test
    @Disabled("TODO: Complete this test")
    void testGetAvailableSlots2() {
        // TODO: Complete this test.
        //   Reason: R013 No inputs found that don't throw a trivial exception.
        //   Diffblue Cover tried to run the arrange/act section, but the method under
        //   test threw
        //   java.lang.NullPointerException: Cannot invoke "com.cognizant.booking_facility.feign.RegistrationFeign.getTokenValidation(String)" because "this.feign" is null
        //       at com.cognizant.booking_facility.controller.BookingController.getAvailableSlots(BookingController.java:45)
        //   See https://diff.blue/R013 to resolve this issue.

        BookingController bookingController = new BookingController();
        Booking booking = mock(Booking.class);
        doNothing().when(booking).setBookingId(anyInt());
        doNothing().when(booking).setDateOfGame((LocalDate) any());
        doNothing().when(booking).setDob((LocalDate) any());
        doNothing().when(booking).setFirst_name((String) any());
        doNothing().when(booking).setGameName((Game) any());
        doNothing().when(booking).setGroundNumber(anyInt());
        doNothing().when(booking).setLast_name((String) any());
        doNothing().when(booking).setPlayerId((String) any());
        doNothing().when(booking).setTimeOfGame((LocalTime) any());
        booking.setBookingId(123);
        booking.setDateOfGame(LocalDate.ofEpochDay(1L));
        booking.setDob(LocalDate.ofEpochDay(1L));
        booking.setFirst_name("Jane");
        booking.setGameName(Game.CRICKET);
        booking.setGroundNumber(10);
        booking.setLast_name("Doe");
        booking.setPlayerId("42");
        booking.setTimeOfGame(LocalTime.of(1, 1));
        bookingController.bookSlots(booking, "ABC123");
    }

    /**
     * Method under test: {@link BookingController#getAvailableSlots(String)}
     */
    @Test
    void testGetAvailableSlots3() throws Exception {
        PlayerResponse playerResponse = new PlayerResponse();
        playerResponse.setId("42");
        playerResponse.setToken("ABC123");
        playerResponse.setValid(true);
        when(registrationFeign.getTokenValidation((String) any())).thenReturn(playerResponse);
        when(slotService.getAllAvailableSlots()).thenReturn(new ArrayList<>());
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/availableSlots")
                .header("Authorization", "Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==");
        MockMvcBuilders.standaloneSetup(bookingController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("[]"));
    }
    
    
}

