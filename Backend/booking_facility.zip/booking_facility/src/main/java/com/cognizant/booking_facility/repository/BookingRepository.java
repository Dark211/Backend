package com.cognizant.booking_facility.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.booking_facility.entity.Booking;
import com.cognizant.booking_facility.entity.Game;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

public interface BookingRepository extends JpaRepository<Booking, Integer> {


    Optional<Booking> findFirstByGameNameOrderByGroundNumberDesc(Game game);
    Optional<Booking> findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc(Game game, LocalDate dateOfGame, LocalTime timeOfGame);
}