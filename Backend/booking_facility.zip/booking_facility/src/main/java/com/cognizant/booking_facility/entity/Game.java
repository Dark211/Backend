package com.cognizant.booking_facility.entity;

public enum Game {
    CRICKET,
    FOOTBALL,
    BADMINTON
}

