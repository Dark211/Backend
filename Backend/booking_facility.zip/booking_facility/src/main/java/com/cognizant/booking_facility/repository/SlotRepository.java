package com.cognizant.booking_facility.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.booking_facility.entity.Slot;

public interface SlotRepository extends JpaRepository<Slot, Integer> {
}