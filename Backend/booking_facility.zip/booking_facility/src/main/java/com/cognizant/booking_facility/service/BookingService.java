package com.cognizant.booking_facility.service;

import com.cognizant.booking_facility.entity.Booking;
import com.cognizant.booking_facility.entity.Game;
import com.cognizant.booking_facility.entity.GameDetails;
import com.cognizant.booking_facility.repository.BookingRepository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public Booking doBooking(Booking bookingSlot) {
        if (bookingSlot.getGameName().equals(Game.CRICKET)) {
            Optional<Booking> existBooking = bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc(Game.CRICKET, bookingSlot.getDateOfGame(), bookingSlot.getTimeOfGame());

            if (existBooking.isPresent()) {
                if (existBooking.get().getDateOfGame().isEqual(bookingSlot.getDateOfGame())) {
                    if (existBooking.get().getTimeOfGame().equals(bookingSlot.getTimeOfGame())) {
                        int existGndNo = existBooking.get().getGroundNumber();
                        if (existGndNo == GameDetails.CRICKET_GROUND) return null;
                        bookingSlot.setGroundNumber(existGndNo + 1);
                        Booking b = bookingRepository.save(bookingSlot);
                        return b;
                    }
                }
            }
            bookingSlot.setGroundNumber(1);
            Booking b = bookingRepository.save(bookingSlot);
            return b;
        }
        if (bookingSlot.getGameName().equals(Game.FOOTBALL) && bookingSlot.getGroundNumber() <= GameDetails.FOOTBALL_GROUND) {
            Optional<Booking> existBooking = bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc(Game.FOOTBALL, bookingSlot.getDateOfGame(), bookingSlot.getTimeOfGame());
            if (existBooking.isPresent()) {
                if (existBooking.get().getDateOfGame().isEqual(bookingSlot.getDateOfGame())) {
                    if (existBooking.get().getTimeOfGame().equals(bookingSlot.getTimeOfGame())) {
                        int existGndNo = existBooking.get().getGroundNumber();
                        if (existGndNo == GameDetails.FOOTBALL_GROUND) return null;
                        bookingSlot.setGroundNumber(existGndNo + 1);
                        Booking b = bookingRepository.save(bookingSlot);
                        return b;
                    }
                }

            }
            bookingSlot.setGroundNumber(1);
            Booking b = bookingRepository.save(bookingSlot);
            return b;
        }
        if (bookingSlot.getGameName().equals(Game.BADMINTON)) {
            Optional<Booking> existBooking = bookingRepository.findFirstByGameNameAndDateOfGameAndTimeOfGameOrderByGroundNumberDesc(Game.BADMINTON, bookingSlot.getDateOfGame(), bookingSlot.getTimeOfGame());
            if (existBooking.isPresent()) {
                log.info(existBooking.toString());
                if (existBooking.get().getDateOfGame().isEqual(bookingSlot.getDateOfGame())) {
                    if (existBooking.get().getTimeOfGame().equals(bookingSlot.getTimeOfGame())) {
                        int existGndNo = existBooking.get().getGroundNumber();
                        if (existGndNo == GameDetails.BADMINTON_GROUND) return null;
                        bookingSlot.setGroundNumber(existGndNo + 1);
                        Booking b = bookingRepository.save(bookingSlot);
                        return b;
                    }
                }
            }
            bookingSlot.setGroundNumber(1);
            Booking b = bookingRepository.save(bookingSlot);
            return b;
        }
        return null;
    }
}
