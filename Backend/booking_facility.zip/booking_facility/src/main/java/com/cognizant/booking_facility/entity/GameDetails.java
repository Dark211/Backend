package com.cognizant.booking_facility.entity;

public class GameDetails {
    public static final String CRICKET = "CRICKET";
    public static final String FOOTBALL = "FOOTBALL";
    public static final String BADMINTON= "BADMINTON";
    public static final int CRICKET_GROUND = 2;
    public static final int FOOTBALL_GROUND = 1;
    public static final int BADMINTON_GROUND = 3;
}
