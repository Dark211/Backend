package com.cognizant.booking_facility;

import com.cognizant.booking_facility.entity.Game;
import com.cognizant.booking_facility.entity.GameDetails;
import com.cognizant.booking_facility.entity.Slot;
import com.cognizant.booking_facility.repository.SlotRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
@EnableFeignClients
public class BookingFacilityApplication {

    @Autowired
    private SlotRepository slotRepository;

    public static void main(String[] args) {
        SpringApplication.run(BookingFacilityApplication.class, args);
    }

    @PostConstruct
    public void doInject() {
        List<Slot> slotDetails = Arrays.asList(
                new Slot(1,true,0,GameDetails.CRICKET_GROUND,Game.CRICKET),
                new Slot(2,true,0,GameDetails.FOOTBALL_GROUND,Game.FOOTBALL),
                new Slot(3,true,0,GameDetails.BADMINTON_GROUND,Game.BADMINTON)

        );
        slotRepository.saveAll(slotDetails);
    }
}
