package com.cognizant.updateplayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class UpdateplayerApplicationTests {

	@Test
	void contextLoads() {
	}
	@Test
    void main() {
		UpdateplayerApplication.main(new String[] {});
    }

}
