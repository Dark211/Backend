package com.authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationApplicationTests {

    @Test
    void contextLoads() {
    }
    @Test
    void main() {
    	AuthenticationApplication.main(new String[] {});
    }

}
