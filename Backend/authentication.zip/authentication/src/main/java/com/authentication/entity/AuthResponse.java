package com.authentication.entity;


import lombok.Data;

@Data
public class AuthResponse {
    private String username;
    private boolean isValid;
}
